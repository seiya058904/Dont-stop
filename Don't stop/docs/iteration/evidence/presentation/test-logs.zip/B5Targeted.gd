extends "res://tests/B5Bosses.gd"
func _ready():
	await boot()
	var result = await fight(20,"B02",400,300000,true)
	print("B5_TARGETED_B02 ",JSON.stringify(result))
	print("B5_TARGETED_CHECKS=",checks," FAILURES=",failures)
	if failures: get_tree().quit(1)
	else: await Demo.quit_game()
